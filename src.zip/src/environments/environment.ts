// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,

  firebaseConfig :{
    apiKey: "AIzaSyCuFzKYNEbHEF_9EE5jEvoONaHi9ofJrMg",
    authDomain: "registerform-4db5b.firebaseapp.com",
    databaseURL: "https://registerform-4db5b-default-rtdb.firebaseio.com",
    projectId: "registerform-4db5b",
    storageBucket: "registerform-4db5b.appspot.com",
    messagingSenderId: "848027797570",
    appId: "1:848027797570:web:dae86eaa019189392d05db",
    measurementId: "G-XGX6J8ZFT3"
  }
  
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
