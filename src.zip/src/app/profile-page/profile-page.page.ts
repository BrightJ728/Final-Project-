import { Component, OnInit } from '@angular/core';

import { ProfileService, Teachers} from 'src/app/services/User.service';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFirestore } from '@angular/fire/firestore';

import { Platform } from '@ionic/angular';
import { SpeechRecognition } from '@ionic-native/speech-recognition/ngx';
import { ChangeDetectorRef } from '@angular/core';
import { MenuController } from '@ionic/angular';
@Component({
  selector: 'app-profile-page',
  templateUrl: './profile-page.page.html',
  styleUrls: ['./profile-page.page.scss'],
})
export class ProfilePagePage implements OnInit {

  user: any;
  private profiles: Observable<Teachers[]>;

  public ProfileList: any[];
  public loadedsearchList: any[];

  matches: String[];
  isRecording = false;
  match: string;

  constructor(private firestore: AngularFirestore, public afAuth: AngularFireAuth, private ProfileService: ProfileService, public router: Router, private platform: Platform, private speechRecognition: SpeechRecognition, private cd: ChangeDetectorRef,private menu: MenuController) 
  { this.menu.enable(true, 'custom');}

  async ngOnInit() {

    this.afAuth.onAuthStateChanged((user) => {
      if (user) {
        this.user = user;
        console.log(this.user);

        this.firestore.collection('profiles', ref => ref.where('host_id', '==', this.user.uid))
        .valueChanges({idField:'id'}).subscribe(ProfileList => {
          this.ProfileList = ProfileList;
          this.loadedsearchList = ProfileList;
        });


      }
    })

    this.profiles = this.ProfileService.getProfiles();
  }

  initializeItems():void {
    this.ProfileList= this.loadedsearchList;
  }

  ionViewDidEnter() {
    
  }

  signOut() {
    return this.afAuth.signOut().then(() => {
      this.router.navigate(['login']);
    })
  }

  getPermission() {
    this.speechRecognition.hasPermission()
    .then((hasPermission: boolean) => {
      if (!hasPermission) {
        this.speechRecognition.requestPermission();
      }
    });
  }

 
  isIos() {
    return this.platform.is('ios');
  }
}