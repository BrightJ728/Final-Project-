import { Component, OnInit, ViewChild } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';
import { ProfileService, Teachers } from 'src/app/services/User.service';
import { ToastController } from '@ionic/angular';

import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFirestore } from '@angular/fire/firestore';
import { HttpClient } from '@angular/common/http';
import { Camera } from '@ionic-native/camera/ngx';

import { Geolocation } from '@ionic-native/geolocation/ngx';
import { NativeGeocoder, NativeGeocoderOptions, NativeGeocoderResult } from '@ionic-native/native-geocoder/ngx';
import { MenuController } from '@ionic/angular';


interface Loc {
  id: number,
  location: string
}
@Component({
  selector: 'app-profile-details',
  templateUrl: './profile-details.page.html',
  styleUrls: ['./profile-details.page.scss'],
})
export class ProfileDetailsPage implements OnInit {

  imageURL: any;
  user: any;

  homeProfile: Teachers = {
     first_name: '',
   surname: '',
    location: '',
    education: '',
    experience: '',
    courses: '',
    description: '',
    image: '',
    host_email: '',
    host_phone: ''
  };

  
  array: any;

  constructor(private camera: Camera, private afs: AngularFirestore, public afAuth: AngularFireAuth,
    private activatedRoute: ActivatedRoute, private ProfileService: ProfileService,
    private toastCtrl: ToastController, private router: Router, private geolocation: Geolocation,
    private nativeGeocoder: NativeGeocoder, private http: HttpClient, private menu: MenuController) 
    {  this.menu.enable(true, 'custom');}
 
  ngOnInit() {
    this.afAuth.onAuthStateChanged((user) => {
      if (user) {
        this.user = user;
        console.log(this.user);
      }

      this.afs.collection('users').valueChanges().subscribe()
    })
   }

  ionViewWillEnter() {
    let id = this.activatedRoute.snapshot.paramMap.get('id');
    if (id) {
      this.ProfileService.getProfile(id).subscribe( homeProfile => {
        this.homeProfile = homeProfile;
      });
    }
  }

  ionViewDidEnter() {
    this.afAuth.onAuthStateChanged((user) => {
      if (user) {
        this.user = user;
        console.log(this.user);
      }
    })
  }

  @ViewChild('fileButton') fileButton

  uploadFile() {
		this.fileButton.nativeElement.click()
	}
  
   sliderOpt = {
    zoom: {
      maxRatio: 1,
    },
  };
  
  
  fileChanged(event) {
    const files = event.target.files;

    const data = new FormData();
    data.append('File', files[0]);
    data.append('UPLOADCARE_STORE', '1');
    data.append('UPLOADCARE_PUB_KEY', '392173d14a45484f430d')

    this.http.post('https://upload.uploadcare.com/base/', data, {})
    .subscribe(event => {
      console.log(event);
      
      var val = JSON.stringify([event['File']])
      var val1 = JSON.parse(val);
      this.imageURL = val1;
    })
  }
 
  addHome() {
   
    const first_name = this.homeProfile.first_name;
     const location = this.homeProfile.location;
    const surname = this.homeProfile.surname;
    const experience = this.homeProfile.experience;
    const education = this.homeProfile.education;
    const courses = this.homeProfile.courses
    const description = this.homeProfile.description;
    const image = this.imageURL[0];
    const host_email = this.user.email;
    const host_id = this.user.uid;
    const host_phone = this.homeProfile.host_phone;
    return new Promise<any>((resolve, reject) => {
      this.afs.collection('profiles').add({
               first_name: first_name,
        location: location,
        surname: surname,
        education: education,
        courses: courses,
        experience: experience,
        description: description,
        image: image,
        host_email: host_email,
        host_phone: host_phone,
        host_id: host_id
      })
      .then(
        res => resolve(res),
        err => reject(err)
      )
    }).then(() => {
      this.router.navigateByUrl('profile-page');
      this.showToast('Profile added');
    })
   
  }
 
  deleteHome() {
    if(confirm('Your profile will be deleted')){
      this.ProfileService.deleteHome(this.homeProfile.id).then(() => {
        this.router.navigateByUrl('profile-page');
        this.showToast('Profile deleted');
      }, err => {
        this.showToast('There was a problem deleting your Profile ');
      });
    }
  }
 
  updateHome() {
    this.ProfileService.updateHome(this.homeProfile).then(() => {
      this.router.navigateByUrl('profile-page');
      this.showToast('Profile updated');
      this.showToast('Profile details updated');
    }, err => {
      this.showToast('There was a problem updating your Profile');
    });
  }
 
  showToast(msg) {
    this.toastCtrl.create({
      message: msg,
      duration: 2000
    }).then(toast => toast.present());
  }
}