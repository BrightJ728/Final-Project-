import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Camera} from '@ionic-native/camera/ngx';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';

import { ProfileDetailsPageRoutingModule } from './profile-details-routing.module';

import { ProfileDetailsPage } from './profile-details.page';
import { RouteReuseStrategy } from '@angular/router';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ProfileDetailsPageRoutingModule
  ],
  providers: [
    Camera,
    {provide: RouteReuseStrategy, useClass: IonicRouteStrategy}
  ],

  declarations: [ProfileDetailsPage],
  bootstrap: [ProfileDetailsPage]
})
export class ProfileDetailsPageModule {}
