import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AllProfilesPageRoutingModule } from './all-profiles-routing.module';

import { AllProfilesPage } from './all-profiles.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AllProfilesPageRoutingModule
  ],
  declarations: [AllProfilesPage]
})
export class AllProfilesPageModule {}
