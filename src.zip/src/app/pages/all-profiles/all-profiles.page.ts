import { Component, OnInit } from '@angular/core';

import { HomeService, Teachers } from 'src/app/services/home.service';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFirestore } from '@angular/fire/firestore';

import { Platform } from '@ionic/angular';
import { SpeechRecognition } from '@ionic-native/speech-recognition/ngx';
import { ChangeDetectorRef } from '@angular/core';
import { MenuController } from '@ionic/angular';


@Component({
  selector: 'app-all-profiles',
  templateUrl: './all-profiles.page.html',
  styleUrls: ['./all-profiles.page.scss'],
})
export class AllProfilesPage implements OnInit {

  user: any;
  private profiles: Observable<Teachers[]>;

  public ProfileList: any[];
  public loadedsearchList: any[];

  matches: String[];
  isRecording = false;
  match: string;

  constructor( private menu: MenuController,private firestore: AngularFirestore, public afAuth: AngularFireAuth, private homeService: HomeService, public router: Router, private platform: Platform, private speechRecognition: SpeechRecognition, private cd: ChangeDetectorRef) 
   { this.menu.enable(true, 'custom'); }

  async ngOnInit() {

    this.afAuth.onAuthStateChanged((user) => {
      if (user) {
        this.user = user;
        console.log(this.user);

        this.firestore.collection('profiles')
        .valueChanges({idField:'id'}).subscribe(ProfileList => {
          this.ProfileList = ProfileList;
          this.loadedsearchList = ProfileList;
        });


      }
    })

    this.profiles = this.homeService.getProfiles();
  }
  

  signOut() {
    return this.afAuth.signOut().then(() => {
      this.router.navigate(['login']);
    })
  }
  initializeItems():void {
    this.ProfileList= this.loadedsearchList;
  }

  filterList(evt){
    this.initializeItems();
    const searchTerm = evt.srcElement.value; 
    if(!searchTerm){
      return; 
    }
    this.ProfileList= this.ProfileList.filter(currentGoal =>{
      if(currentGoal.location && searchTerm ||currentGoal.courses && searchTerm){
        if(currentGoal.courses.toLowerCase().indexOf(searchTerm.toLowerCase())>-1 || currentGoal.location.toLowerCase().indexOf(searchTerm.toLowerCase())>-1){
          return true; 
        }
        return false; 
      }
    });
  }

  ionViewDidEnter() {
    
  }



  getPermission() {
    this.speechRecognition.hasPermission()
    .then((hasPermission: boolean) => {
      if (!hasPermission) {
        this.speechRecognition.requestPermission();
      }
    });
  }

 
  startListening() {
    let options = {
      language: 'en-US',
    }

    this.speechRecognition.hasPermission()
    .then((hasPermission: boolean) => {
      if (!hasPermission) {
        this.speechRecognition.requestPermission();
      }
    });

    this.speechRecognition.startListening().subscribe(matches => {
      this.match = matches[0];
      this.cd.detectChanges();
    })

    this.isRecording = true;

    this.filterList(this.match);
  }

  stopListening() {
    this.speechRecognition.stopListening().then(() => {
      this.isRecording = false;
    })
  }


  isIos() {
    return this.platform.is('ios');
  }
}

