import { Component, OnInit, ViewChild } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';
import { HomeService, Teachers } from 'src/app/services/home.service';
import { ToastController } from '@ionic/angular';

import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFirestore } from '@angular/fire/firestore';
import { HttpClient } from '@angular/common/http';

import { Geolocation } from '@ionic-native/geolocation/ngx';
import { NativeGeocoder, NativeGeocoderOptions, NativeGeocoderResult } from '@ionic-native/native-geocoder/ngx';
import { MenuController } from '@ionic/angular';

interface Loc {
  id: number,
  location: string
}
@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.page.html',
  styleUrls: ['./view-details.page.scss'],
})
export class ViewDetailsPage implements OnInit {
  
  imageURL: any;
  user: any;

  home: Teachers = {
    
    first_name: '',
    surname: '',
     location: '',
     education: '',
     experience: '',
     courses: '',
     description: '',
     image: '',
     host_email: '',
     host_phone: ''
  };

  // Readable Address
  address: string;

  // Location coordinates
  latitude: any = 0;
  longitude: any = 0;
  accuracy: number;

  //Geocoder configuration
  geoencoderOptions: NativeGeocoderOptions = {
    useLocale: true,
    maxResults: 5
  };
  array: any;

  constructor(private menu: MenuController, private afs: AngularFirestore, public afAuth: AngularFireAuth,
    private activatedRoute: ActivatedRoute, private homeService: HomeService,
    private toastCtrl: ToastController, private router: Router, private geolocation: Geolocation,
    private nativeGeocoder: NativeGeocoder, private http: HttpClient) 
    {   this.menu.enable(false, 'custom');}
 
  ngOnInit() {
    this.afAuth.onAuthStateChanged((user) => {
      if (user) {
        this.user = user;
        console.log(this.user);
      }

      this.afs.collection('users').valueChanges().subscribe()
    })
   }

  ionViewWillEnter() {
    let id = this.activatedRoute.snapshot.paramMap.get('id');
    if (id) {
      this.homeService.getProfile(id).subscribe(home => {
        this.home = home;
      });
    }
  }

  ionViewDidEnter() {
    this.afAuth.onAuthStateChanged((user) => {
      if (user) {
        this.user = user;
        console.log(this.user);
      }
    })
  }

  @ViewChild('fileButton') fileButton

  uploadFile() {
		this.fileButton.nativeElement.click()
	}

  sliderOpt = {
    zoom: {
      maxRatio: 1,
    },
  };

  fileChanged(event) {
    const files = event.target.files;

    const data = new FormData();
    data.append('File', files[0]);
    data.append('UPLOADCARE_STORE', '1');
    data.append('UPLOADCARE_PUB_KEY', '392173d14a45484f430d')

    this.http.post('https://upload.uploadcare.com/base/', data, {})
    .subscribe(event => {
      console.log(event);
      
      var val = JSON.stringify([event['File']])
      var val1 = JSON.parse(val);
      this.imageURL = val1;
    })
  }
}
 