import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ViewTeachersPageRoutingModule } from './view-teachers-routing.module';

import { ViewTeachersPage } from './view-teachers.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ViewTeachersPageRoutingModule
  ],
  declarations: [ViewTeachersPage]
})
export class ViewTeachersPageModule {}
