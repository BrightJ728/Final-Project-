import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ViewTeachersPage } from './view-teachers.page';

const routes: Routes = [
  {
    path: '',
    component: ViewTeachersPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ViewTeachersPageRoutingModule {}
