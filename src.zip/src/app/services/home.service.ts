import { Injectable } from '@angular/core';

import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument, DocumentReference } from '@angular/fire/firestore';
import { map, take } from 'rxjs/operators';
import { Observable } from 'rxjs';

export interface Teachers {
  id?: string,
  
  description: string,
  image: string,
  host_email: string,
  host_phone: string
location:string,
  first_name: string,
  surname: string,
  courses: string,
  experience: string,
  education: string
}

@Injectable({
  providedIn: 'root'
})
export class HomeService {
  private profiles: Observable<Teachers[]>;
  private homeCollection: AngularFirestoreCollection<Teachers>;
 
  constructor(private afs: AngularFirestore) {
    this.homeCollection = this.afs.collection<Teachers>('profiles');
    this.profiles = this.homeCollection.snapshotChanges().pipe(
      map(actions => {
        return actions.map(a => {
          const data = a.payload.doc.data();
          const id = a.payload.doc.id;
          return { id, ...data };
        });
      })
    );
  }
 
  getProfiles(): Observable<Teachers[]> {
    return this.profiles;
  }
 
  getProfile(id: string): Observable<Teachers> {
    return this.homeCollection.doc<Teachers>(id).valueChanges().pipe(
      take(1),
      map(home => {
        home.id = id;
        return home
      })
    );
  }
 
  addHome(home: Teachers): Promise<DocumentReference> {
    return this.homeCollection.add(home);
  }
 
  updateHome(home: Teachers): Promise<void> {
    return this.homeCollection.doc(home.id).update({  location:home.location, first_name: home.first_name,  surname: home.surname, education: home.education, experience:home.experience, courses:home.courses, description: home.description, image: home.image, host_email: home.host_email, host_phone: home.host_phone});
  }
 
  deleteHome(id: string): Promise<void> {
    return this.homeCollection.doc(id).delete();
  }
}
