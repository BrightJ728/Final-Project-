import { Injectable } from '@angular/core';

import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument, DocumentReference } from '@angular/fire/firestore';
import { map, take } from 'rxjs/operators';
import { Observable } from 'rxjs';

export interface Teachers {
  id?: string,
   description: string,
   location:string,
  image: string,
  host_email: string,
  host_phone: string
  first_name: string,
  surname: string,
  courses: string,
  experience: string,
  education: string
}

@Injectable({
  providedIn: 'root'
})
export class ProfileService {
  getHomeProfile(id: string) {
    throw new Error('Method not implemented.');
  }
  private profiles: Observable<Teachers[]>;
  private homeCollection: AngularFirestoreCollection<Teachers>;
 
  constructor(private afs: AngularFirestore) {
    this.homeCollection = this.afs.collection<Teachers>('profiles');
    this.profiles = this.homeCollection.snapshotChanges().pipe(
      map(actions => {
        return actions.map(a => {
          const data = a.payload.doc.data();
          const id = a.payload.doc.id;
          return { id, ...data };
        });
      })
    );
  }
 
  getProfiles(): Observable<Teachers[]> {
    return this.profiles;
  }
 
  getProfile(id: string): Observable<Teachers> {
    return this.homeCollection.doc<Teachers>(id).valueChanges().pipe(
      take(1),
      map(homeProfile => {
        homeProfile.id = id;
        return homeProfile
      })
    );
  }
 
  addHome(homeProfile: Teachers): Promise<DocumentReference> {
    return this.homeCollection.add(homeProfile);
  }
 
  updateHome(homeProfile: Teachers): Promise<void> {
    return this.homeCollection.doc(homeProfile.id).update({ location:homeProfile.location, first_name:homeProfile.first_name, surname:homeProfile.surname, education: homeProfile.education, experience: homeProfile.experience, courses: homeProfile.courses, description: homeProfile.description, image: homeProfile.image, host_email: homeProfile.host_email, host_phone: homeProfile.host_phone});
  }
 
  deleteHome(id: string): Promise<void> {
    return this.homeCollection.doc(id).delete();
  }
}
