import { TestBed } from '@angular/core/testing';

import { ProfileService } from './User.service';

describe('ProfileService', () => {
  let services: ProfileService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    services = TestBed.inject(ProfileService);
  });

  it('should be created', () => {
    expect(services).toBeTruthy();
  });
});
