import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-tab',
  templateUrl: './menu-tab.page.html',
  styleUrls: ['./menu-tab.page.scss'],
})
export class MenuTabPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
